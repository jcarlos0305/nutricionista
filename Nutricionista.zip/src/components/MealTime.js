import React, { Component } from 'react';
import { Text, View, Image, TouchableOpacity, TimePickerAndroid, Picker } from 'react-native';
import Card from './Card';
import CardSection from './CardSection';

class MealTime extends Component {
  state = { selectedFood: 'Alimento' };

  async showTimePicker() {
    try {
      const { action, hour, minute } = await TimePickerAndroid.open({
        hour: 14,
        minute: 0,
        is24Hour: true,
      });
      if (action !== TimePickerAndroid.dismissedAction) {
        console.log(hour + ' ' + minute);
      }
    } catch ({ code, message }) {
      console.warn('Cannot open time picker', message);
    }
  }

  render() {
    return (
      <Card>
        <CardSection>
          <View style={styles.imageContainerStyle}>
            <TouchableOpacity>
              <Image
                style={styles.imageStyle}
                source={{ uri: 'http://www.freeiconspng.com/uploads/cancel-close-button-png-9.png' }}
              />
            </TouchableOpacity>
          </View>

          <View style={styles.headerContentStyle}>
            <Text style={styles.headerTextStyle}>{this.props.mealTime.nombre}</Text>
          </View>

          <View style={styles.imageContainerStyle}>
            <TouchableOpacity onPress={() => this.showTimePicker()}>
              <Image
                style={styles.imageStyle}
                source={{ uri: 'http://www.freeiconspng.com/uploads/alarm-clock-time-icon--11.png' }}
              />
            </TouchableOpacity>
          </View>

        </CardSection>

        <CardSection>
          <Picker
            style={{ flex: 1 }}
            selectedValue={this.state.selectedFood}
            onValueChange={(itemValue, itemIndex) => this.setState({selectedFood: itemValue})}
          >
            <Picker.Item label="Almidones" value="Almidones" />
            <Picker.Item label="Proteínas" value="Proteínas" />
            <Picker.Item label="Vegetales" value="Vegetales" />
            <Picker.Item label="Frutas" value="Frutas" />
            <Picker.Item label="Lácteos" value="Lácteos" />
            <Picker.Item label="Grasas" value="Grasas" />
            <Picker.Item label="Azúcares" value="Azúcares" />
          </Picker>
        </CardSection>

      </Card>
    );
  }
}

const styles = {
  headerContentStyle: {
    flexDirection: 'column',
    justifyContent: 'space-around'
  },
  headerTextStyle: {
    fontSize: 15
  },
  imageStyle: {
    height: 20,
    width: 20
  },
  imageContainerStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    marginRight: 10
  }
};

export default MealTime;
