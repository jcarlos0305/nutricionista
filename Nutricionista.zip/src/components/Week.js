import React from 'react';
import { View } from 'react-native';
import DatePicker from './DatePicker';

const Week = () => {
  return (
    <View>
      <DatePicker />
    </View>
  );
};

export default Week;
